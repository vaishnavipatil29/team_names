#include<iostream>
#include<fstream>


#define weeklyUpdate "inputFile.txt"
#define parentFile "expectedFloorFile.txt"
#define finalLiftPos "finalLiftPositions.txt"
#define d1 7 //i No. of days 
#define d2 24 //j No. of time slots
#define d3 21 //k Number of floors
#define c1 0.6 //changing constant in ML
#define c2 0.7 
using namespace std;
float expectedW[7][24]; //contains prevoius floor preferences
int liftPos[24][3];

class week
{	
public:
	int d[d1][d2][d3]; 
	float actual[7][24];
	week()
	{
		for(int i=0;i<d1;i++)
			for(int j=0;j<d2;j++)
				for (int k=0;k<d3;k++)
				{
					d[i][j][k]=0;
				}
	}

	week(int a)
	{
		for(int i=0;i<d1;i++)
			for(int j=0;j<d2;j++)
				for (int k=0;k<d3;k++)
				{
					d[i][j][k]=a;
				}
	}
	void txtreader()
	{
		ifstream infile(weeklyUpdate);
		int a, count = 1;
		while(infile >> a)
		{
			d[(count-1)/(d2*d3)][((count-1)/d3)%d2][(count-1)%d3] = a;
			count++;
		}
		infile.close();
	}

	void weeklyFileProcessing()
	{
		txtreader();
		float nsum=0, dsum=0;
		float wsum=0;
		for(int i=0;i<d1;i++)
		{
			for(int j=0;j<d2;j++)
			{	
				nsum=0;dsum=0;
				for (int k=0;k<d3;k++)
				{
					nsum += d[i][j][k]*(k);
					dsum += d[i][j][k];
				}
				wsum = nsum/dsum;
				actual[i][j] = wsum;
			}
		}
	}

	void printActual()
	{
		for (int i = 0; i < d1; ++i)
		{
			for (int j = 0; j < d2; ++j)
			{
				cout << actual[i][j] << " ";
			}
			cout << endl;
		}
	}	

	void printArr()
	{
		for(int i=0;i<d1;i++)
		{
			for(int j=0;j<d2;j++)
			{
				for (int k=0;k<d3;k++)
				{
					cout << d[i][j][k] << " ";
				}
			cout << endl;
			}
		cout << endl << endl << endl;
		}
	}
}a,b;

void parentFileReader()
{
	ifstream infile(parentFile);
	float a; int count=1;
	while(infile >> a)
		{
			expectedW[(count-1)/d2][(count-1)%d2] = a;
			count++;
		}
	for (int i = 0; i < d1; ++i)
		{
			for (int j = 0; j < d2; ++j)
			{
				cout << expectedW[i][j] << " ";
			}
			cout << endl;
		}
		infile.close();
}

void ML()
{
	for (int i=0;i<d1;i++)
	{
		for(int j=0;j<d2;j++)
		{
			expectedW[i][j] = expectedW[i][j] + (a.actual[i][j] - expectedW[i][j])*c1;
		}
	}

	for (int i = 0; i < d1; ++i)
		{
			for (int j = 0; j < d2; ++j)
			{
				cout << expectedW[i][j] << " ";
			}
	}
}

void parentFileUpdate()
{
	ofstream outfile(parentFile);
	
	for (int i=0;i<d1;i++)
	{
		for(int j=0;j<d2;j++)
			{outfile << expectedW[i][j] << " ";}
		outfile << endl;
	}
	outfile.close();
}

void finalPos()
{
	ofstream outfile(finalLiftPos);
	float a=0,b=0;
	int lift1pos = 0, lift2pos, lift3pos;
	
	for(int i=0;i<d1;i++)
	{
		outfile << "Day:" << i+1 << endl;

		outfile<<"TIME SLOTS     Lift1  Lift2  Lift3" <<endl;
		for(int j=0;j<d2;j++)
		{
			a = (expectedW[i][j]-10.5)*c2 + 8;
			b = (expectedW[i][j]-10.5)*c2 + 16;
			lift2pos = (int)(a-0.5)-1;
			lift3pos = (int)(b-0.5)-1;
			if(lift3pos>18)
				lift3pos = 18;
			if (lift2pos>14)
				lift2pos=14;
			outfile << j << ":00-" << j+1 <<":00    	"<<lift1pos << "       " << lift2pos << "      " << lift3pos << endl;
		}
		outfile << endl << endl;
	}
	outfile.close();
}

int main()
{
	/*
	a.txtreader();
	a.printArr();*/
	cout<<"Actual:- "<<endl<<endl;
	a.weeklyFileProcessing();
	a.printActual();
	cout<<endl<<endl<<"Expected:- "<<endl<<endl;
	parentFileReader();
	cout<<endl<<endl<<"New Expected:- "<<endl<<endl;
	ML();
	parentFileUpdate();
	finalPos();
}