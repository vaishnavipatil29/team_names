<!DOCTYPE html>
<html lang="en">
<head>
	<title>Welcome</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="login/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="login/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="login/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="login/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="login/vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="login/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="login/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="login/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="login/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="login/css/util.css">
	<link rel="stylesheet" type="text/css" href="login/css/main.css">
<link href="https://fonts.googleapis.com/css?family=Cuprum" rel="stylesheet"><!--===============================================================================================-->
</head>
<body>
	<div class="limiter">
		<div class="container-login100" style="background-image: url('../fitfat/images/bkg.jpg'); background-color: black; background-position: center; text-align:center; background-repeat:no-repeat;background-size: contain;">
			<div class="wrap-login100 p-t-90 p-b-30">
				<form class="login100-form validate-form">
					<span class="login100-form-title p-b-40" style="color: white;  text-align: center; font-size: 50px; font-family: 'Cuprum', sans-serif;">
						ONCE YOU SEE RESULTS, <br>IT BECOMES AN
					<br>ADDICTION
					</span>
					<div class="wrapper p-t-150" style="text-align: center;">
						<a href="signup.php"><button type="button" class="btn-lg btn-warning" style="align: center; font-family: 'Cuprum', sans-serif;"><i class="fa fa-star"></i>&nbsp;START NOW</button></a>
					</div>
					<div class="flex-col-c p-t-100">
						<span class="txt2 p-b-10" style="color: white;font-family: 'Cuprum', sans-serif;">
							Already have an account?
						</span>

						<a href="login.php" class="txt3 bo1 hov1" style="color: white;font-family: 'Cuprum', sans-serif;">
							Login
						</a>
					</div>

				</form>
			</div>
		</div>
	</div>


<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
