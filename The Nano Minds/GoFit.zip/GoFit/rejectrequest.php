<?php
include 'config_db.php';
include('session.php');
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$i=$_POST['email1'];
//echo $i;
$sql1 = "delete from Company_check where Email_id=\"".$i."\"";
//echo $sql1;
$result1 = mysqli_query($conn, $sql1);

if($result1) {
  echo "<script>alert(\"Request Rejected!!\");window.location.href='pages-log-viewer.php'</script>";
}
else  {
  echo "<script>alert('".mysqli_error($conn)."'); window.location.href='pages-log-viewer.php'</script>";
}
?>
