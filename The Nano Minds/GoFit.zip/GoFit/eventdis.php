<?php
include 'session.php';
include 'config_db.php';

?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
  * {
    box-sizing: border-box;
  }

  #input1-group2 {
    background-image: url('/css/searchicon.png');
    background-position: 10px 12px;
    background-repeat: no-repeat;
    font-size: 16px;
    padding: 12px 20px 12px 40px;
    border: 1px solid #ddd;
    margin-bottom: 12px;
  }

  #myUL {
    list-style-type: none;
    padding: 0;
    margin: 0;
  }

  #myUL li a {
    border: 1px solid #ddd;
    margin-top: -1px; /* Prevent double borders */
    background-color: #f6f6f6;
    padding: 12px;
    text-decoration: none;
    font-size: 18px;
    color: black;
    display: block
  }

  #myUL li a:hover:not(.header) {
    background-color: #eee;
  }
  </style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sufee Admin - HTML5 Admin Template</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

<link href="https://fonts.googleapis.com/css?family=Cuprum" rel="stylesheet">


</head>

<body class="bg-dark">
  <!-- Left Panel -->

  <aside id="left-panel" class="left-panel">
      <nav class="navbar navbar-expand-sm navbar-default">

        <div class="navbar-header">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="./"><img src="images/logo-white.png" alt="Logo" height="30px"></a>
            <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
        </div>

          <div id="main-menu" class="main-menu collapse navbar-collapse">
              <ul class="nav navbar-nav">
                  <li>
                      <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                  </li>
                  <li>
                      <a href="leaderboard.php"> <i class="menu-icon fa fa-trophy"></i>Leaderboard </a>
                  </li>
                  <li>
                      <a href="goal.php"> <i class="menu-icon fa fa-list-alt"></i>Goal </a>
                  </li>
                  <h3 class="menu-title">Event</h3><!-- /.menu-title -->
                  <li><a href="event.php"> <i class="menu-icon fa fa-calendar-plus-o"></i>Add Event </a></li>
                  <li class="active"><a href="eventdis.php"> <i class="menu-icon fa fa-calendar"></i>View Event </a></li>



              </ul>
          </div><!-- /.navbar-collapse -->
      </nav>
  </aside><!-- /#left-panel -->

  <!-- Left Panel -->

  <!-- Right Panel -->

  <div id="right-panel" class="right-panel">

      <!-- Header-->
      <header id="header" class="header">

          <div class="header-menu">

              <div class="col-sm-7">
                  <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                  <div class="header-left">

                  </div>
              </div>

              <div class="col-sm-5">
                  <div class="user-area dropdown float-right">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src=<?php echo $_SESSION['image'];?> alt="User Avatar">
                      </a>

                      <div class="user-menu dropdown-menu">
                          <a class="nav-link" href="profile.php"><i class="fa fa-user"></i> My Profile</a>

                          <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                      </div>
                  </div>
              </div>
          </div>

      </header><!-- /header -->
      <!-- Header-->
    <div class="col-lg-12">
        <div class="card">



  <center><h2><label for="inputSuccess2i" class=" form-control-label">My Events</label><h2></center>
    <div>



    <ul id="myUL">
    <?php
    include 'config_db.php';
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
    //echo $_SESSION['userid'];
      $sql = "select * from `friends` where `id`='".$_SESSION['userid']."'";
        $result = mysqli_query($conn,$sql);
        if (mysqli_num_rows($result) > 0) {

      	  while ($row1 = mysqli_fetch_array($result)){
            $id=$row1[2];
            $sql2 = "select * from `events` where `user_id`='".$id."' order by date desc limit 10";
              $result2 = mysqli_query($conn,$sql2);
              if (mysqli_num_rows($result2) > 0) {
            	  while ($row = mysqli_fetch_array($result2)){
                  $postedid=$row[1];
                  $name=$row[3];
                  $des=$row[4];
                  $date=$row[5];
                  $time=$row[6];
                  $ven=$row[7];
                  $img=$row[8];
                  ?>
                  <li><div>
                                  <div class="card">
                                      <div class="card-body">
                                          <div class="stat-widget-one">
                                            <div class="form-control-label"><h4><?php echo $name?></h4>
                                              <br>
                                              <p style="float:right;"><h7><?php echo $des?></h7></p>
                                              <div class="stat-icon dib"><img class="align-self-center rounded-circle mr-3" style="width:85px; height:85px;" alt="" src="<?php echo $img?>"></div>
                                              <div class="stat-content dib">


                                                <h6>Date: <?php echo $date?>     &nbsp &nbsp Time: <?php echo $time?></h6>
                                                  <h6>Venue: <?php echo $ven?></h6>
                                                  <br><h6>Posted By:
                                                    <?php
                                                    // echo $postedid;
                                                  $sql1 = "select username from `users` where `id`=".$postedid;
                                                    $result2 = mysqli_query($conn,$sql1);
                                                    if (mysqli_num_rows($result2) > 0) {
                                                      while ($row2 = mysqli_fetch_array($result2)){
                                                        $name1= $row2['username'];
                                                      }
                                                    }
                                                    else{
                                                      echo "nooo";
                                                    }

                                                      echo $name1;
                                                      ?>
                                                        </h6>
                                                </div>

                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div></li>
    <?php }
    }else{
echo "<hr>";
  echo "<li><center><h5>No Event</center></li><h5>";
}
    }
    }
    ?>

  </ul></div>

</form>

</div>


        </div>
    </div>
                            <script src="vendors/jquery/dist/jquery.min.js"></script>
                            <script src="vendors/popper.js/dist/umd/popper.min.js"></script>

                            <script src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
                            <script src="vendors/jquery-validation-unobtrusive/dist/jquery.validate.unobtrusive.min.js"></script>

                            <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
                            <script src="assets/js/main.js"></script>


</body>
</html>
