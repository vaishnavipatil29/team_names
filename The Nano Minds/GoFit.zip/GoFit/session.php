<?php
   include('config_db.php');
   session_start();

   $session_id = $_SESSION['userid'];

   if(!isset($_SESSION['userid'])){
      header('location:login.php');
   }
?>
