<?php
include 'config_db.php';
include 'session.php';
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$id = $_GET['id'];
$tag = $_GET['tag'];
// echo "TAG: " . $tag;

$sql = " SELECT * FROM `student` WHERE `Email` = '".$session_email."'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
 while ($row = mysqli_fetch_array($result)){
 $rollno = $row['Roll_no'];
 }
}


if ($tag==0) {
  $sql = "INSERT INTO `follows` values ('".$rollno."','".$id."','0')";
  if (mysqli_query($conn, $sql)) {
    echo "<script type=\"text/javascript\">";
    echo "alert (\"Friend Request Sent Successfully\");";
    echo "window.location.href='user-account.php';";
    echo "</script>";
  }
  else {
    echo "<script type=\"text/javascript\">";
    echo "alert (\"Internal Error, Retry\");";
    echo "window.location.href='user-account.php';";
    echo "</script>";
  }
}
else {
  $sql = "UPDATE `follows` SET `status`=1 WHERE `following`='".$rollno."' AND `follower`='".$id."'";
  if (mysqli_query($conn, $sql)) {
    echo "<script type=\"text/javascript\">";
    echo "alert (\"Accepted\");";
    echo "window.location.href='user-account.php';";
    echo "</script>";
  }
  else {
    echo "<script type=\"text/javascript\">";
    echo "alert (\"Internal Error, Retry\");";
    echo "window.location.href='user-account.php';";
    echo "</script>";
  }
}
?>
