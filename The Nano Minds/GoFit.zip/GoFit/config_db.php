<?php
	$servername = "localhost";//use the sql server Name
	$username = "root";//use your sql username
	$password = ""; //use your sql password
	$dbname = "gofitorfat";// Please do not change this line
?>
