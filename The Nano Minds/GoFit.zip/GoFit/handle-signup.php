<?php
include 'config_db.php';
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
  //fullname, username, email, password, city, phone,
    $_POST['password'] = hash('sha256', $_POST['password']);
    $sql0 = "insert into `users` (`username`,`email`,`password`,`location`,`phone` ) values ('".$_POST['username']."','".$_POST['email']."','".$_POST['password']."','".$_POST['city']."','".$_POST['phone']."')";
    // echo $sql0;
    $sql = "select username from users where username='".$_POST['username']."'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
      echo "<script type=\"text/javascript\">";
      echo "alert (\"Username taken, choose another one!\");";
      echo "window.location.href='signup.php';";
      echo "</script>";
      return;
    }

    $result0 = mysqli_query($conn, $sql0);
    if ($result0) {
        echo "<script type=\"text/javascript\">";
        echo "alert (\"New Account created Successfully... Sign In with your new account now!\");";
        echo "window.location.href='login.php';";
        echo "</script>";
    }
    else {
        echo "<script type=\"text/javascript\">";
        echo "alert (\"Internal Error... Please Try Again!\");";
        echo "window.location.href='signup.php';";
        echo "</script>";
        // echo mysqli_error($conn);
    }
?>
