<?php
include 'config_db.php';
session_start();

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$name=$_SESSION['userid'];
if(isset($_POST['duration'],$_POST['sport'])){
  $duration=$_POST['duration'];
  $sports=$_POST['sport'];
  $sql = "INSERT INTO activity(user_id, category_name, duration) VALUES ($name,'{$sports}',$duration)";
  $result = mysqli_query($conn,$sql);
//update score

  $sql = "select sum(score) from scorecard where user_id='{$_SESSION['userid']}'";
  $result = mysqli_query($conn,$sql);
  if ($row = mysqli_fetch_assoc($result)) {
    $score=$row['sum(score)'];
  }
  $sql1 = "select calories_perhour,calories_burnt from category where category_name='{$sports}'";
  $result1 = mysqli_query($conn,$sql1);
  if($row1 = mysqli_fetch_assoc($result1)) {
         $calories=$row1['calories_perhour']*$weight*$duration/(60*68);
     }
  $score=$calories/$row1['calories_burnt']*10;
  $sql = "insert into `scorecard` (`userid`,`score`,`timestamp`) values (".$_SESSION['userid'].",".$score.", now())";
  $result = mysqli_query($conn,$sql);
}
echo "<script type=\"text/javascript\">";
echo "window.location.href='dashboard.php';";
echo "</script>";


?>
