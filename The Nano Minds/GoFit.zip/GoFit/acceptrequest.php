<?php
include 'config_db.php';
include('session.php');
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$a=$_POST['name'];
$b=$_POST['addr'];
$c=$_POST['country'];
$d=$_POST['pin'];
$e=$_POST['website'];
$f=$_POST['desc'];
$g=$_POST['typeorg'];
$h=$_POST['nature'];
$i=$_POST['email'];
$sql = "insert into `company` values(\"".$a."\",\"".$b."\",\"".$c."\",".$d.",\"".$e."\",\"".$f."\",\"".$g."\",\"".$h."\",\"".$i."\")";
$sql1 = "delete from `company_check` where Email_id=\"".$i."\"";
$result = mysqli_query($conn, $sql);
$result1 = mysqli_query($conn, $sql1);

if($result AND $result1) {
  echo "<script>alert(\"Request Accepted!!\");window.location.href='instr_front_page.php'</script>";



  //echo "Hello updated successfully";
}
else  {
  echo "<script>alert('".mysqli_error($conn)."'); window.location.href='instr_front_page.php'</script>";
  //echo "not updates";
  //  echo mysqli_error($conn);
}
?>
