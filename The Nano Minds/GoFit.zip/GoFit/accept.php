<?php
session_start();
include 'config_db.php';

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$id=mysqli_real_escape_string($conn, $_POST['cid']);

  $sql = "update challenges SET status='".$_POST['state']."' where challenge_id='".$id."'";
  $result = mysqli_query($conn,$sql);
  if($_POST['state']==2){
    $sql = "insert into `scorecard` (`userid`,`score`,`timestamp`) values (".$_SESSION['userid'].",5, now())";
    $result = mysqli_query($conn,$sql);
  }

?>
