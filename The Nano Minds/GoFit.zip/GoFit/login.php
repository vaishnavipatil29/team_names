<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

<link href="https://fonts.googleapis.com/css?family=Cuprum" rel="stylesheet">




</head>

<body style="background-color: black;">


    <div class="sufee-login d-flex align-content-center flex-wrap" >
        <div class="container"  style="background-image: url('../fitfat/images/bkg.jpg'); background-color: black; background-position: center; text-align:center; background-repeat:no-repeat;background-size: contain;">
            <div class="login-content" >
              <div class="login-logo">
                  <a href="dashboard.php">
                      <img class="align-content" src="images/logo-white.png" alt="">
                  </a>
              </div>


                        <form action="handle-login.php" method="post">

                            <div class="form-group">
                                <div class="input-group" style="font-family: 'Cuprum', sans-serif;">
                                    <div class="input-group-addon"><i class="fa fa-user"></i></div>
                                    <input type="text" id="username" name="username" placeholder="Username" class="form-control">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="input-group" style="font-family: 'Cuprum', sans-serif;">
                                    <div class="input-group-addon"><i class="fa fa-asterisk"></i></div>
                                    <input type="password" id="password" name="password" placeholder="Password" class="form-control">
                                </div>
                            </div>
                            <br><br><br><br>
                            <br>
                            <div class="form-actions form-group" style="font-family: 'Cuprum', sans-serif;"><button type="submit" class="btn-lg btn-warning">Login</button>

                            </div>
  <div style="align: center;">
                            <div class="flex-col-c p-t-100" style="text-align: center;">
                              <span class="txt2 p-b-10" style="color: white;  font-family: 'Cuprum', sans-serif;">
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;New User?
                              </span>

                              <a href="signup.php" class="txt3 bo1 hov1" style="color: white; text-align: center; font-family: 'Cuprum', sans-serif;">
                                Sign Up!
                              </a>
                            </div>
</div>

                        </form>



                </div>
            </div>
        </div>
    </div>


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>

</html>
