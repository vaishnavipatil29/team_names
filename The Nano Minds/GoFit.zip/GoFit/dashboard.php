warning<?php

include 'config_db.php';
include 'session.php';
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


if (isset($_SESSION['userid'])) {
  $sql = "select * from `users` where `id`='".$_SESSION['userid']."'";
  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {
	  while ($row = mysqli_fetch_array($result)){
      $id=$row['id'];
      $user=$row['username'];
      $email=$row['email'];
      $institute=$row['institute'];
      $city=$row['location'];
      $gender=$row['gender'];
      $age=$row['age'];
      $height=$row['height'];
      $weight=$row['weight'];
      $phone=$row['phone'];
      $ref_code=$row['ref_code'];
      $image=$row['image'];
    }
  }
$_SESSION['image']=$image;
  $sql = "select count(*) from challenges where (status=0 or status=1) and user_id='{$_SESSION['userid']}'";
  $result = mysqli_query($conn,$sql);
  if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
           $count=$row['count(*)'];
       }
  }
 ?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">


    <link rel="stylesheet" href="assets/css/style.css">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Cuprum" rel="stylesheet">    <style>
    .hidden { display: none; }
    .unhidden { display: inline; }
    </style>




</head>

<body class="bg-dark" style="font-family: 'Cuprum', sans-serif; ">

    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="images/logo-white.png" alt="Logo" height="30px"></a>
                <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <li>
                        <a href="leaderboard.php"> <i class="menu-icon fa fa-trophy"></i>Leaderboard </a>
                    </li>
                    <li>
                        <a href="goal.php"> <i class="menu-icon fa fa-list-alt"></i>Goal</a>
                    </li>
                    <li>
                        <a href="challenge.php"> <i class="menu-icon fa fa-bolt"></i>Challenge</a>
                    </li>
                    <h3 class="menu-title">Event</h3><!-- /.menu-title -->
                    <li><a href="event.php"> <i class="menu-icon fa fa-calendar-plus-o"></i>Add Event </a></li>
                    <li><a href="eventdis.php"> <i class="menu-icon fa fa-calendar"></i>View Event </a></li>



                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">

                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <img class="user-avatar rounded-circle" src=<?php echo $image;?> alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="profile.php"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->



        <div class="content mt-3">
<?php

$calories=0;
$score=0;
$level=1;

$sql = "select category_name,duration from activity where user_id='{$_SESSION['userid']}' and (_date between '".date("Y-m-d")." 00:00:00' and '".date("Y-m-d")." 23:59:59')";
$result = mysqli_query($conn,$sql);
if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    $sql1 = "select calories_perhour,calories_burnt from category where category_name='{$row['category_name']}'";
    $result1 = mysqli_query($conn,$sql1);
    if($row1 = mysqli_fetch_assoc($result1)) {
           $calories=$calories + $row1['calories_perhour']*$weight*$row['duration']/(60*68);
       }
     }
}
// echo $calories;
$sql = "select sum(score) from scorecard where userid='{$_SESSION['userid']}'";
$result = mysqli_query($conn,$sql);
if ($row = mysqli_fetch_assoc($result)) {
  $score1=$row['sum(score)'];
  $level=intval($score1/20)+1;
}
$sql = "select count(*) from challenges where status=2 and user_id='{$_SESSION['userid']}'";
$result = mysqli_query($conn,$sql);
if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
         $c=$row['count(*)'];
     }
}
$badge="No badge";
if($c>2 and $c<5){
$badge="Rookie";
}else if($c>=5 and $c<9){
$badge="Semi Pro";
}else if($c>=9 and $c<13){
$badge="Pro";
}
else if($c>=13 and $c<20){
$badge="Veteran";
}
else if($c>=20 and $c<27){
$badge="Expert";
}
else if($c>=27 and $c<35){
$badge="Master";
}
else if($c>=35 and $c<42){
$badge="Legend";
}
else if($c>42){
$badge="Rocketeer";
}

$badge_image="none";
$sql = "select image from badges where badge_name='".$badge."'";
$result = mysqli_query($conn,$sql);
if ($row = mysqli_fetch_assoc($result)) {
  $badge_image=$row['image'];
}

  if ($gender=='' || $age==0 || $weight==0 || $height==0) {
 ?>
            <div class="col-sm-12">
              <div class="alert alert-danger fade show">
                  <span class="badge badge-pill badge-danger" style="position: relative; float: left;">Important</span>
                  <br>You haven't yet completed your profile!<br>
                  <a href="profile.php"><button class="btn btn-danger">Do It Now!</button></a>

              </div>
            </div>
          <?php } ?>
          <div class="p-l-20">
            <div class="card col-lg-2 col-md-6">
                <div class="card-body bg-flat-color-3">
                    <div class="h1 text-right mb-4">
                        <i class="fa fa-bar-chart-o text-dark"  style="padding-right: 5px;"></i>
                        <h3 style="position: relative; float: left;"> Daily Progress </h3>
                    </div>
                    <div style="display: inline-block;">
                      <?php
                      date_default_timezone_set('Asia/Kolkata');
                      $today_string = date("Y-m-d");
                      $today = date_create($today_string);
                      $sqlda="SELECT * from `scorecard` where `userid`='".$session_id."' and `timestamp` like '".$today_string."%'";
                      $resultda = mysqli_query($conn, $sqlda);
                      if (mysqli_num_rows($resultda) > 0) {
                            echo "<div style=\"display: inline-block; text-align: center \">";
                            echo "<i class=\"fa fa-check-circle\" style=\"color: green; font-size: 40px; padding-left: 10px;\"></i>";
                            echo "<br>";
                            echo "<small>".$today->format('D')."</small>";
                            echo "</div>";
                      }
                      else {
                        echo "<div style=\"display: inline-block; text-align: center \">";
                        echo "<i class=\"fa fa-check-circle\" style=\"color: gray; font-size: 40px; padding-left: 10px;\"></i>";
                        echo "<br>";
                        echo "<small>".$today->format('D')."</small>";
                        echo "</div>";
                      }
                    ?>
                    <?php
                      for ($i=6; $i>0; $i=$i-1) {
                        $temp = date_sub($today,date_interval_create_from_date_string("1 day"));
                        $temp1=$temp->format('Y-m-d');
                        // echo "temp1 ".$temp1;
                        $sqlda="SELECT * from `scorecard` where `userid`='".$session_id."' and `timestamp` like '".$temp1."%'";
                        $resultda = mysqli_query($conn, $sqlda);
                        if (mysqli_num_rows($resultda) > 0) {
                              echo "<div style=\"display: inline-block; text-align: center \">";
                              echo "<i class=\"fa fa-check-circle\" style=\"color: green; font-size: 40px; padding-left: 10px;\"></i>";
                              echo "<br>";
                              echo "<small>".$temp->format('D')."</small>";
                              echo "</div>";
                        }
                        else {
                          echo "<div style=\"display: inline-block; text-align: center \">";
                          echo "<i class=\"fa fa-check-circle\" style=\"color: gray; font-size: 40px; padding-left: 10px;\"></i>";
                          echo "<br>";
                          echo "<small>".$temp->format('D')."</small>";
                          echo "</div>";
                        }
                      }
                      ?>


                    </div>
                </div>
            </div>
          </div>

          <div class="col-sm-6 col-lg-3">
                          <div class="card text-white bg-flat-color-1">
                              <div class="card-body pb-0">

                                  <h4 class="mb-0">
                                    <?php
                                    $sql = "select sum(score) from `scorecard` where `userid`='".$_SESSION['userid']."'";
                                      $result = mysqli_query($conn,$sql);
                                      if (mysqli_num_rows($result) > 0) {
                                        while ($row = mysqli_fetch_array($result)){
                                          $count=$row['sum(score)'];
                                        }
                                      }
                                          ?>

                                            <h2>My Score
                                      <span class="count"><?php echo $count?></span></h2>
                                  </h4>
                                  <br>
                                  <?php
                                  $sum=0;
                                  $sql = "select * from `scorecard` where `userid`='".$_SESSION['userid']."' order by timestamp desc";
                                    $result = mysqli_query($conn,$sql);
                                    if (mysqli_num_rows($result) > 0) {

                                      while ($row = mysqli_fetch_array($result)){
                                        $score=$row['score'];
                                        $t = $row[2];
                                        $datetime = explode(" ",$t);
                                        $d2=explode(" ",date('Y-m-d H:i:s'));
                                        $date = $datetime[0];
                                        $date2=$d2[0];

                                        if($date==$date2){
                                          $sum=$sum+$score;
                                        }

                                        //$time = $datetime[1];
                                      }?>
                                      <p class="text-light">Today's Score <?php echo $sum?></p>
                                      <?php
                                    }
                                    ?>

                                  <div class="chart-wrapper px-0" style="height:70px;" height="70"><div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;"><div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div></div><div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:200%;height:200%;left:0; top:0"></div></div></div>
                                      <canvas id="widgetChart1" height="140" width="696" class="chartjs-render-monitor" style="display: block; height: 70px; width: 348px;"></canvas>

                                  </div>

                              </div>

                          </div>
                      </div>



              <div class="col-lg-4 col-md-6">
                  <section class="card">
                      <div class="twt-feed blue-bg">
                          <div class="corner-ribon black-ribon">
                              <i class="fa fa-trophy"></i>
                          </div>
                          <div class="fa fa-heartbeat wtt-mark"></div>

                          <div class="media">
                              <a href="#"><img class="align-self-center rounded-circle mr-3" style="width:85px; height:85px;" alt="" src=<?php echo $image;?>>
                              </a>
                              <div class="media-body">
                                  <h2 class="text-white display-6"><?php echo $user;?></h2>
                                  <p class="text-light"><?php echo $badge;?> <img class="align-self-center mr-3" style="width:50px; height:50px;" alt="" src=<?php echo $badge_image;?>></p>


                              </div>
                          </div>



                  </div>
                  <div class="weather-category twt-category" >
                      <ul >
                          <li class="active" style="color:black;">
                              <h5><?php echo $score1;?></h5>
                              Score
                          </li>
                          <li style="color:black;">
                              <h5><?php echo intval($calories);?> cal</h5>
                              <img src="images/calorie.png">
                          </li>
                          <li style="color:black;">
                              <h5><?php echo $level;?></h5>
                              Level
                          </li>
                      </ul>
                  </div>

              </section>
          </div>



          <div class="col-md-4">
              <div class="card">
                  <div class="card-header">
                      <strong class="card-title">Add New Activity <span class="badge badge-warning float-right mt-1">+</span></strong>
                  </div>
                  <div class="card-body">
                      <p class="card-text" style="text-align: center;">

                        <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#myModal"> Click Here to Add</button>

                        <div class="modal fade" id="myModal" role="dialog">
                          <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">Add Activity</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <div class="modal-body">
                                <form method="POST" action="addactivity.php">
                                Duration (in min)<input type="number" placeholder="in minutes" name="duration" required><br><br>
                                <input id="hiddenInput" type="hidden" name="sport" value="none">
                                <!-- <center> -->
                                <div id="ko" class="unhidden">
                                  <input type="image"  alt="submit" onclick="$('#hiddenInput').val('walk')" src="images/walking.svg" class="img-responsive" style="display:inline;"  border="1" width="100" height="100">
                                  <input type="image"  alt="submit" onclick="$('#hiddenInput').val('run')" src="images/running.png" class="img-responsive" style="display:inline;" border="1"  width="100" height="100">
                                  <input type="image"  alt="submit" onclick="$('#hiddenInput').val('swim')"  src="images/swimming.png" class="img-responsive" style="display:inline;" border="1"  width="100" height="100">
                                  <br>
                                  <input type="image"  alt="submit" onclick="$('#hiddenInput').val('dance')"  src="images/dance.svg" class="img-responsive" style="display:inline;" border="1"  width="100" height="100">

                                  <img src="images/sports.png" onclick="unhide123('ko');unhide123('ko1');" style="float:left;border:1px solid;" width="100" height="100">
                                  <input type="image"  alt="submit" onclick="$('#hiddenInput').val('gym')"  src="images/gym.png" class="img-responsive" style="display:inline;" border="1"  width="100" height="100">
                                  <br>
                                  <input type="image"  alt="submit" onclick="$('#hiddenInput').val('cycling')"  src="images/cycling.png" class="img-responsive" style="display:inline;"  border="1" width="100" height="100">
                                  <input type="image"  alt="submit" onclick="$('#hiddenInput').val('yoga')"  src="images/yoga.png" class="img-responsive" style="display:inline;" border="1"  width="100" height="100">

                                </div>
                                <div id='ko1' class="hidden">
                                <input type="image"  alt="submit" onclick="$('#hiddenInput').val('batminton')"  src="images/badminton.png" class="img-responsive"  style="display:inline;" border="1" width="100" height="100">
                                <input type="image"  alt="submit" onclick="$('#hiddenInput').val('basketball')" src="images/basketball.svg" class="img-responsive"   style="display:inline;" border="1" width="100" height="100">
                                <input type="image"  alt="submit" onclick="$('#hiddenInput').val('volleyball')"  src="images/volley.svg" class="img-responsive"  style="display:inline;"  border="1" width="100" height="100">

                                <br>
                                <input type="image"  alt="submit" onclick="$('#hiddenInput').val('cricket')"  src="images/cricket.svg" class="img-responsive"  style="display:inline;" border="1"  width="100" height="100">
                                <input type="image"  alt="submit" onclick="$('#hiddenInput').val('football')"  src="images/football.png" class="img-responsive"  style="display:inline;" border="1"  width="100" height="100">
                              </div>
                              <!-- </center> -->
                            </form>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary"type="button" data-dismiss="modal">Cancel</button>
                                <!-- <button type="button" class="btn btn-primary" type="button" >Confirm</button> -->
                              </div>
                            </div>

                          </div>
                        </div>


                      </p>
                  </div>
              </div>
          </div>


          <div class="col-md-4">
              <div class="card">
                  <div class="card-header">
                      <strong class="card-title">Daily Challenge</strong>
                  </div>
                  <div class="card-body" style="text-align: center;" >
                    <button type="button" class="btn btn-lg btn-warning mb-1" data-toggle="modal" data-target="#smallmodal">
                        Try Now!
                    </button>

                    <div class="modal fade" id="smallmodal" tabindex="-1" role="dialog" aria-labelledby="smallmodalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-sm" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="smallmodalLabel">Today's Challenge </h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p>
                                         <?php
                                            if (date('l') == 'Sunday') {
                                              echo "<strong>".date('l')."</strong>";
                                              echo "<p> Take it light today with 10 minutes of Yoga.</p>";
                                            }
                                            if (date('l') == 'Monday') {
                                              echo "<strong>".date('l')."</strong>";
                                              echo "<p> Jog around the campus for around 20 minutes.</p>";
                                            }
                                            if (date('l') == 'Tuesday') {
                                              echo "<strong>".date('l')."</strong>";
                                              echo "<p> Don't get out of your room, just push-ups and crunches for 30 minutes.</p>";
                                            }
                                            if (date('l') == 'Wednesday') {
                                              echo "<strong>".date('l')."</strong>";
                                              echo "<p> Ride off into the sunset for a 45 minute cycle ride</p>";
                                            }
                                            if (date('l') == 'Thursday') {
                                              echo "<strong>".date('l')."</strong>";
                                              echo "<p> Hit the gym and lift some weights for 30 minutes.</p>";
                                            }
                                            if (date('l') == 'Friday') {
                                              echo "<strong>".date('l')."</strong>";
                                              echo "<p> Walk at your own leisurey pace for 45 minutes.</p>";
                                            }
                                            if (date('l') == 'Saturday') {
                                              echo "<strong>".date('l')."</strong>";
                                              echo "<p> Shoot a basket, or score a goal for 1 hour.</p>";
                                            }



                                         ?>
                                    </p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                    <!-- <button type="button" class="btn btn-primary">Confirm</button> -->
                                </div>
                            </div>
                        </div>
                    </div>



                  </div>
              </div>
          </div>



          <div class="col-md-4">
              <div class="card">
                  <div class="card-header">
                      <strong class="card-title">Previous Activity</strong>
                  </div>
                  <div class="card-body" style="text-align: center;" >
                    <button type="button" class="btn btn-lg btn-warning mb-1" data-toggle="modal" data-target="#smallmodal5">
                        View
                    </button>

                    <div class="modal fade" id="smallmodal5" tabindex="-1" role="dialog" aria-labelledby="smallmodalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-sm" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="smallmodalLabel">Previous Activities</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">

                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Activity</th>
                                                <th scope="col">Duration</th>
                                                <th scope="col">Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php
                                          $sql1 = "select * from `activity` where user_id=".$_SESSION['userid'];
                                          $result1 = mysqli_query($conn,$sql1);
                                          if (mysqli_num_rows($result1) > 0) {
                                            $t1=1;
                                          while ($row = mysqli_fetch_array($result1)){
                                            ?>
                                            <tr>
                                                <td><?php echo $t1;?></td>
                                                <td><?php echo $row[2];?></td>
                                                <td><?php echo $row[4];?></td>
                                                <td><?php echo $row[3];?></td>
                                            </tr>


                                  <?php
                                  $t1=$t1+1;
                                  }

                                  }

                                  ?>
                                </tbody>
                            </table>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>



                  </div>
              </div>
          </div>





          <div class="col-md-4">
            <?php
            $sql = "select count(*) from challenges where (status=0 or status=1) and user_id='{$_SESSION['userid']}'";
  $result = mysqli_query($conn,$sql);
  if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
           $count=$row['count(*)'];
       }
  }
  ?>
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Challenges <span class="badge badge-warning float-right mt-1"><?php echo $count;?></span></strong>
                            </div>
                            <div class="card-body">

                            <?php
                            $sql = "select challenge_id,friend_id,ch_name,description,status from challenges where (status=1 or status=0) and user_id='{$_SESSION['userid']}'";
                            $result = mysqli_query($conn,$sql);
                            if (mysqli_num_rows($result) > 0) {
                              while($row = mysqli_fetch_assoc($result)) {
                                $sql1 = "select image from users where id='{$row['friend_id']}'";
                                $result1 = mysqli_query($conn,$sql1);
                                $row1 = mysqli_fetch_assoc($result1);
                                ?>
                              <div class="col-lg-3 col-md-6">
                                  <div class="card">
                                      <div class="card-body">
                                        <div class="stat-widget-four">
                                            <div class="col-2">
                                                <img style="border-radius: 50%;" src=<?php echo $row1['image']?>  width="80px" height="60px" alt="" />
                                            </div>
                                            <!-- <div class="stat-content"> -->
                                                <div style="margin-left:10px;" class="col-6">
                                                    <strong><?php echo $row['ch_name'];?></strong>
                                                    <div ><?php echo $row['description'];?></div>
                                                    </div>
                                                    <div class="col-3 <?php echo $row['status'] == 0 ? 'unhidden' : 'hidden';?>" class="col-3">
                                                      <form method="POST" onclick="return confirm('Are you sure?');" action="accept.php">
                                                        <input type="hidden" name="cid" value=<?php echo $row['challenge_id'];?> >
                                                        <button name="state" style="margin-bottom:7px;" class="btn btn-primary" type="submit" value=1>Accept</button>
                                                        <button name="state"class="btn btn-danger" type="submit" value=-1>Decline</button>
                                                      </form>
                                                    </div>
                                                    <div class="col-3 <?php echo $row['status'] == 1 ? 'unhidden' : 'hidden';?>"  class="col-3">
                                                      <form method="POST" onclick="return confirm('Are you sure?');" action="accept.php">
                                                        <input type="hidden" name="cid" value=<?php echo $row['challenge_id'];?> >
                                                        <button name="state" style="margin-bottom:7px;" class="btn btn-primary" type="submit" value=2>Completed</button>
                                                        <button name="state" class="btn btn-danger" type="submit" value=3>Incompleted</button>
                                                      </form>
                                                    </div>

                                            <!-- </div> -->
                                        </div>
                                          </div>
                                      </div>
                                  </div>
                            <?php }
                                  } ?>
                              </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header">
                                    <strong class="card-title">Recommended Users </strong>
                                </div>
                                <div class="card-body">
                                  <?php
                                  $sql = "SELECT distinct `friend_user_id` from `friends` where `id` in (select `friend_user_id` from `friends` where id='".$session_id."') AND `friend_user_id`!='".$session_id."' AND `friend_user_id` not in (select `friend_user_id` from `friends` where `id`='".$session_id."')";
                                  $result = mysqli_query($conn, $sql);
                                  if (mysqli_num_rows($result)>0) {
                                    while ($row=mysqli_fetch_array($result)) {
                                      // echo "<img class=\"align-self-center rounded-circle mr-3\" style=\"width:85px; height:85px;\" alt=\"\" src=\"images/admin.jpg\">";
                                      $sql_getdata = "SELECT distinct * from `users` where `id`='".$row['friend_user_id']."'";
                                      $result_data = mysqli_query($conn, $sql_getdata);
                                      if (mysqli_num_rows($result_data)>0) {
                                        while ($row_data=mysqli_fetch_array($result_data)) {
                                          echo "Name: " . $row_data['username'] . "<br>";
                                          echo "<img class=\"align-self-center rounded-circle mr-3\" style=\"width:85px; height:85px;\" alt=\"\" src=\"images/admin.jpg\">";
                                          echo "City: " . $row_data['location'] . "<br>";
                                        }
                                      }
                                    }
                                  }
                                  else {
                                    $sql="SELECT * from `users` WHERE `location`='" . $city . "' AND `id` not in (select `friend_user_id` from `friends` where `id`='".$session_id."') AND `id`!='".$session_id."'";
                                    $result = mysqli_query($conn, $sql);
                                    if (mysqli_num_rows($result)>0) {
                                      while ($row=mysqli_fetch_array($result)) {
                                        // echo "<img class=\"align-self-center rounded-circle mr-3\" style=\"width:85px; height:85px;\" alt=\"\" src=\"images/admin.jpg\">";
                                        $sql_getdata = "SELECT distinct * from `users` where `id`='".$row['id']."'";
                                        $result_data = mysqli_query($conn, $sql_getdata);
                                        if (mysqli_num_rows($result_data)>0) {
                                          while ($row_data=mysqli_fetch_array($result_data)) {
                                            echo "Name: " . $row_data['username'];
                                            echo "<img class=\"align-self-center rounded-circle mr-3\" style=\"width:85px; height:85px;\" alt=\"\" src=\"images/admin.jpg\">";
                                            echo "City: " . $row_data['location'];
                                          }
                                        }
                                      }
                                    }
                                  }

                                   ?>
                                </div>
                            </div>
                        </div>



        </div> <!-- .content -->
    </div><!-- /#right-panel -->
<?php
} else {
  echo "shit";
}
 ?>
    <!-- Right Panel -->
    <script type="text/javascript">
    function unhide123(divID) {
    var item = document.getElementById(divID);
    if (item) {
    item.className=(item.className=='hidden')?'unhidden':'hidden';
    }
    }
    </script>
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <!-- <script src="assets/js/widgets.js"></script> -->
    <script src="vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script>
        (function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });
        })(jQuery);
    </script>
    <script type="text/javascript">
    ( function ( $ ) {
        "use strict";


        // Counter Number
        $('.count').each(function () {
            $(this).prop('Counter',0).animate({
                Counter: $(this).text()
            }, {
                duration: 3000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now));
                }
            });
        });

        //WidgetChart 1
        var ctx = document.getElementById( "widgetChart1" );
        ctx.height = 150;
        var myChart = new Chart( ctx, {
            type: 'line',
            data: {
              <?php
              $sql = "select * from (select * from `scorecard` where `userid`='".$_SESSION['userid']."' order by timestamp desc limit 7) sub ORDER BY timestamp ASC";
                $result = mysqli_query($conn,$sql);
                if (mysqli_num_rows($result) > 0) {
                    echo "labels: [";
                  while ($row = mysqli_fetch_array($result)){
                    $score=$row['score'];
                    $t = $row[2];
                    $datetime = explode(" ",$t);
                    $date = $datetime[0];
                    $time = $datetime[1];
                    echo "'".$date."',";
              }
              echo "],";
            }
            ?>


                type: 'line',
                datasets: [ {

                      <?php
                      $sql = "select * from `scorecard` where `userid`='".$_SESSION['userid']."' order by timestamp desc limit 0,7 ";
                        $result = mysqli_query($conn,$sql);
                        if (mysqli_num_rows($result) > 0) {
                            echo "data: [";
                          while ($row = mysqli_fetch_array($result)){
                            $score=$row['score'];
                            $t=$row[2];
                            echo $score.",";
                      }
                      echo "],";
                    }
                    ?>
                    label: 'Score',
                    backgroundColor: 'transparent',
                    borderColor: 'rgba(255,255,255,.55)',
                }, ]
            },
            options: {

                maintainAspectRatio: false,
                legend: {
                    display: false
                },
                responsive: true,
                scales: {
                    xAxes: [ {
                        gridLines: {
                            color: 'transparent',
                            zeroLineColor: 'transparent'
                        },
                        ticks: {
                            fontSize: 2,
                            fontColor: 'transparent'
                        }
                    } ],
                    yAxes: [ {
                        display:false,
                        ticks: {
                            display: false,
                        }
                    } ]
                },
                title: {
                    display: false,
                },
                elements: {
                    line: {
                        borderWidth: 1
                    },
                    point: {
                        radius: 4,
                        hitRadius: 10,
                        hoverRadius: 4
                    }
                }
            }
        } );

    } )( jQuery );
</script>


</body>

</html>
