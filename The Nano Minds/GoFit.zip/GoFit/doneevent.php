<?php
include 'session.php';
include 'config_db.php';
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
echo $_SESSION['userid'];
$ename=$_POST['ename'];
$des=$_POST['des'];
$date=$_POST['date'] ;
$time=$_POST['time'] ;
$venue=$_POST['venue'] ;

$target = 'images/events/';

if (!empty($_FILES)) {

    $fileName = $_FILES['Filename']['name'];
    $fileTarget1 = $target.$fileName;
    $fileTarget1 = mysqli_real_escape_string($conn,$fileTarget1);
    // echo $fileTarget1;
    $tempFileName = $_FILES["Filename"]["tmp_name"];
    $result = move_uploaded_file($tempFileName,$fileTarget1);
    $sql = "insert into events (`user_id`,`status`, `event_name`, `description`, `date`, `time`, `venue`,`image`) VALUES   ('".$_SESSION['userid']."','0','".$ename."','".$des."','".$date."','".$time."','".$venue."','".$fileTarget1."')";
    $RES=mysqli_query($conn,$sql);
}
else {
  echo "image not there";
  $sql = "insert into events (`user_id`,`status`, `event_name`, `description`, `date`, `time`, `venue`) VALUES   ('".$_SESSION['userid']."','0','".$ename."','".$des."','".$date."','".$time."','".$venue."')";
    $result = mysqli_query($conn,$sql);
}

// Storing Selected Value In Variable

if(!empty($_POST['check_list'])){

// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list'] as $selected){
  $sql = "select count(*) from events";
    $result = mysqli_query($conn,$sql);
    if (mysqli_num_rows($result) > 0) {
      while ($row = mysqli_fetch_array($result)){
        $count=$row['count(*)'];
      }
    }
  $sql1 = "insert into friend_events VALUES   ('".$count."','".$selected."')";
    $result = mysqli_query($conn,$sql1);
echo $selected."</br>";
}
}

?>
