<?php

include 'config_db.php';
include 'session.php';
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


if (isset($_SESSION['userid'])) {
  $sql = "select * from `users` where `id`='".$_SESSION['userid']."'";
  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {
	  while ($row = mysqli_fetch_array($result)){
      $id=$row['id'];
      $user=$row['username'];
      $email=$row['email'];
      $institute=$row['institute'];
      $city=$row['location'];
      $gender=$row['gender'];
      $age=$row['age'];
      $height=$row['height'];
      $weight=$row['weight'];
      $phone=$row['phone'];
      $ref_code=$row['ref_code'];
    }
  }

 ?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Profile</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">


    <link rel="stylesheet" href="assets/css/style.css">

<link href="https://fonts.googleapis.com/css?family=Cuprum" rel="stylesheet">
</head>

<body class="bg-dark" style="font-family: 'Cuprum', sans-serif; ">


  <!-- Left Panel -->

  <aside id="left-panel" class="left-panel">
      <nav class="navbar navbar-expand-sm navbar-default">

        <div class="navbar-header">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="./"><img src="images/logo-white.png" alt="Logo" height="30px"></a>
            <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
        </div>

          <div id="main-menu" class="main-menu collapse navbar-collapse">
              <ul class="nav navbar-nav">
                  <li class="active">
                      <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                  </li>
                  <li>
                      <a href="leaderboard.php"> <i class="menu-icon fa fa-trophy"></i>Leaderboard </a>
                  </li>
                  <li>
                      <a href="goal.php"> <i class="menu-icon fa fa-list-alt"></i>Goal</a>
                  </li>
                  <li>
                      <a href="challenge.php"> <i class="menu-icon fa fa-bolt"></i>Challenge</a>
                  </li>
                  <h3 class="menu-title">Event</h3><!-- /.menu-title -->
                  <li><a href="event.php"> <i class="menu-icon fa fa-calendar-plus-o"></i>Add Event </a></li>
                  <li><a href="eventdis.php"> <i class="menu-icon fa fa-calendar"></i>View Event </a></li>



              </ul>
          </div><!-- /.navbar-collapse -->
      </nav>
  </aside><!-- /#left-panel -->

  <!-- Left Panel -->

  <!-- Right Panel -->

  <div id="right-panel" class="right-panel">

      <!-- Header-->
      <header id="header" class="header">

          <div class="header-menu">

              <div class="col-sm-7">
                  <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                  <div class="header-left">

                  </div>
              </div>

              <div class="col-sm-5">
                  <div class="user-area dropdown float-right">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src=<?php echo $_SESSION['image'];?> alt="User Avatar">
                      </a>

                      <div class="user-menu dropdown-menu">
                          <a class="nav-link" href="profile.php"><i class="fa fa-user"></i> My Profile</a>

                          <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                      </div>
                  </div>
              </div>
          </div>

      </header><!-- /header -->
      <!-- Header-->



        <div class="content mt-3">
          <div class="col-md-4 col-xs-12">
          <div class="card">
              <div class="card-body">
                  <!--<div class="mx-auto d-block">
                      <img class="rounded-circle mx-auto d-block" src="images/admin.jpg" alt="Card image cap">
                      <h5 class="text-sm-center mt-2 mb-1" style="text-align: center;"><?php echo $user; ?></h5>
                      <div class="location text-sm-center" style="text-align: center;"><i class="fa fa-map-marker"></i> <?php echo $city;?></div>
                  </div>
                -->
                <div class="card-body">
                  <div class="mx-auto d-block">

                      <?php

                            if($gender=='f') {
                              $sql = "select sum(score) from `scorecard` where `userid`='".$_SESSION['userid']."'";
                              $result = mysqli_query($conn,$sql);
                              if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_array($result)){
                                  $which=$row['sum(score)'];
                                  if($which<50){
                              ?>
                                <img src="images/fatf.png" style="position:relative; float:right;" alt="User Avatar" width="60" height="100">
                              <?php
                            }
                            else if($which<100){
                              ?>
                                <img src="images/medf.png" style="position:relative; float:right;" alt="User Avatar" width="60" height="100">
                              <?php
                            }
                            else {
                              ?>
                                  <img src="images/thinf.png" style="position:relative; float:right;" alt="User Avatar" width="60" height="100">
                              <?php
                            }
                            }
                          }
                        }
                        else{
                          $sql = "select sum(score) from `scorecard` where `userid`='".$_SESSION['userid']."'";
                            $result = mysqli_query($conn,$sql);
                            if (mysqli_num_rows($result) > 0) {
                              while ($row = mysqli_fetch_array($result)){
                                $which=$row['sum(score)'];
                                if($which<50){
                                  ?>
                                    <img src="images/fatm.png" style="position:relative; float:right;" alt="User Avatar" width="60" height="100">
                                  <?php
                                }
                                else if($which<100){
                                  ?>
                                    <img src="images/medm.png" style="position:relative; float:right;" alt="User Avatar" width="60" height="100">
                                  <?php
                                }
                                else {
                                  ?>
                                      <img src="images/thinm.png" style="position:relative; float:right;" alt="User Avatar" width="60" height="100">
                                  <?php
                                }
                                }
                              }

                        }

                          ?>
                          <img class="rounded-circle d-block" src="images/admin.jpg" alt="Card image cap">

                          <h5 class="text-sm-center mt-2 mb-1" style="text-align: center;"><?php echo $user; ?></h5>
                        </div>
                      <div class="location text-sm-right" style="text-align: center;"><i class="fa fa-map-marker"></i> <?php echo $city;?></div>
                  </div>
                  <hr>
                  <div class="card-text text-sm-center">
                    <div class="weather-category twt-category">
                        <ul>
                          <li>
                              <?php
                                $sql1 = "select * from `friends` where `id`='".$_SESSION['userid']."'";
                                $result1=mysqli_query($conn, $sql1);
                                $followings = mysqli_num_rows($result1);

                                $sql2 = "select * from `friends` where `friend_user_id`='".$_SESSION['userid']."'";
                                $result2=mysqli_query($conn, $sql2);
                                $followers = mysqli_num_rows($result2);

 ?>
                              <h5><?php echo $followings; ?></h5>
                              Following
                          </li>
                          <li>
                              <h5><?php echo $followers; ?></h5>
                              Followers
                          </li>
<?php
$sql = "select sum(score) from scorecard where userid='{$_SESSION['userid']}'";
$result = mysqli_query($conn,$sql);
if ($row = mysqli_fetch_assoc($result)) {
  $score1=$row['sum(score)'];
  $level=intval($score1/20)+1;
}

?>
                          <li class="active">
                              <h5><?php echo $level; ?></h5>
                              Level
                          </li>

                        </ul>
                    </div>
                  </div>
              </div>  <hr>

              </div>
              <div class="card-footer" style="text-align: center;">
                <button type="button" class="btn btn-info mb-1" data-toggle="modal" data-target="#update-info">
                    Update!
                </button>
              </div>

              <div class="modal fade" id="update-info" tabindex="-1" role="dialog" aria-labelledby="smallmodalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-sm" role="document">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="smallmodalLabel">Update Information</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                              </button>
                          </div>
                          <div class="modal-body">
                              <p>
                                <div class="card">

                                    <div class="card-body card-block">
                                        <form action="update-details.php" method="post" class="form-inline">
                                            <div class="form-group"><label for="exampleInputName2" class="pr-1  form-control-label">Age</label><input type="number" name="age" id="exampleInputName2" placeholder="Current age..." required="true" class="form-control"></div>
                                            <div class="form-group"><label for="exampleInputName2" class="pr-1  form-control-label">Weight</label><input type="number" step="0.01" name="weight" id="exampleInputName2" placeholder="Weight (in kg)" required="true" class="form-control"></div>
                                            <div class="form-group"><label for="exampleInputName2" class="pr-1  form-control-label">Height</label><input type="number" step="0.01" name="height" id="exampleInputName2" placeholder="Height (in m)" required="true" class="form-control"></div>
                                            <div class="form-group"><label for="exampleInputName2" class="pr-1  form-control-label">Sex</label>
                                              <div class="form-check-inline form-check">
                                                <label for="inline-radio1" class="form-check-label ">
                                                    <input type="radio" id="inline-radio1" name="sex" value="m" class="form-check-input">Male
                                                </label>
                                                <label for="inline-radio2" class="form-check-label ">
                                                    <input type="radio" id="inline-radio2" name="sex" value="f" class="form-check-input">Female
                                                </label>
                                                <label for="inline-radio3" class="form-check-label ">
                                                    <input type="radio" id="inline-radio3" name="sex" value="o" class="form-check-input">Don't Specify
                                                </label>
                                            </div>
                                          </div>
                                          <button type="submit" class="btn btn-info btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                          </button> &nbsp;
                                          <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                          </button>
                                        </form>
                                    </div>

                                </div>

                              </p>
                          </div>
                          <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                          </div>
                      </div>
                  </div>
              </div>


              <div class="card col-md-6 col-xs-12">
                  <div class="card-body">
                      <div class="h1 text-muted text-right mb-4">
                          <i class="fa fa-pie-chart"></i>
                      </div>
                      <div class="h4 mb-0">
                          <span class="count"><?php echo $weight/($height*$height/10000); ?> </span>
                      </div>
                      <small class="text-muted text-uppercase font-weight-bold">Body Mass Index</small>
                      <?php if ($weight/($height*$height/10000) < 18.5) {
                        echo "<div class=\"progress progress-xs mt-3 mb-0 bg-flat-color-5\" style=\"width: 40%; height: 5px;\"></div>";
                      }
                      else if ($weight/($height*$height/10000) < 25 && $weight/($height*$height/10000) >= 18.5) {
                        echo "<div class=\"progress progress-xs mt-3 mb-0 bg-flat-color-3\" style=\"width: 40%; height: 5px;\"></div>";
                      }
                      else if ($weight/($height*$height/10000) >= 25) {
                        echo "<div class=\"progress progress-xs mt-3 mb-0 bg-flat-color-4\" style=\"width: 40%; height: 5px;\"></div>";
                      }


                      ?>
                  </div>
              </div>
              <div class="col-lg-3 col-xs-12">
                  <div class="card">
                      <div class="card-body">
                          <div class="stat-widget-four">
                              <div class="stat-icon dib">
                                  <i class="fa fa-tasks text-muted"></i>
                              </div>
                              <div class="stat-content">
                                  <div class="text-left dib">
                                      <div class="stat-heading">My Activities</div>
                                      <button class="btn btn-sm btn-info"> <strong> > </strong> </button>
                                  </div> <!-- This is for a modal which shows all Achievements -->
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col-lg-3 col-xs-12">
                  <div class="card">
                      <div class="card-body">
                          <div class="stat-widget-four">
                              <div class="stat-icon dib">
                                  <i class="ti-stats-up text-muted"></i>
                              </div>
                              <div class="stat-content">
                                  <div class="text-left dib">
                                      <div class="stat-heading">Achievements</div>
                                      <button class="btn btn-sm btn-info"> <strong> > </strong> </button>
                                  </div> <!-- This is for a modal which shows all Achievements -->
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>

        </div> <!-- .content -->
    </div><!-- /#right-panel -->
<?php
} else {
  echo "shit";
}
 ?>
    <!-- Right Panel -->

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script>
        (function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });
        })(jQuery);
    </script>

</body>

</html>
