<?php

include 'config_db.php';
include 'session.php';
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$height=$_POST['height'];
$weight=$_POST['weight'];
$age=$_POST['age'];
$sex=$_POST['sex'];

$sql = "update `users` set `height`='".$height."', `weight`='".$weight."', `age`='".$age."', `gender`='".$sex."' where `id`='".$_SESSION['userid']."'";
$result = mysqli_query($conn, $sql);

if ($result) {
  echo "<script type=\"text/javascript\">";
  echo "alert (\"Details successfully updated!...\");";
  echo "window.location.href='profile.php';";
  echo "</script>";
}
else {
  echo "<script type=\"text/javascript\">";
  echo "alert (\"Server Error... Please try again\");";
  echo "window.location.href='profile.php';";
  echo "</script>";
}
