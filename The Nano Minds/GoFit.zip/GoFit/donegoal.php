<?php
include 'config_db.php';
include 'session.php';
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
// echo $_SESSION['userid'];
$gname=$_POST['gname'];
$des=$_POST['des'];
$selected_val = $_POST['Cat'];
$start=$_POST['stdate'] ;
$end=$_POST['edate'] ;
$startt=$_POST['sttime'] ;
$endt=$_POST['etime'] ;// Storing Selected Value In Variable
// echo "You have selected :" .$selected_val;  // Displaying Selected Value

  $sql = "insert into goals (`user_id`, `category_name`, `goal_name`, `description`, `status` , `start_date`, `end_date`, `start_time`, `end_time`) VALUES   ('".$_SESSION['userid']."','".$selected_val."','".$gname."','".$des."','0','".$start."','".$end."','".$startt."','".$endt."')";
    $result = mysqli_query($conn,$sql);

    echo "<script> window.location.href='dashboard.php'</script>";

// echo $selected."</br>";

?>
