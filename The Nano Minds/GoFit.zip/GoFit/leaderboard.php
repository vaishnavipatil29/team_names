<?php
session_start();
include 'config_db.php';
$_SESSION['userid']="123";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


if (isset($_SESSION['userid'])) {
  $sql = "select * from `users` where `id`='".$_SESSION['userid']."'";
  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {
	  while ($row = mysqli_fetch_array($result)){
      $id=$row['id'];
      $user=$row['username'];
      $email=$row['email'];
      $institute=$row['institute'];
      $city=$row['location'];
      $gender=$row['gender'];
      $age=$row['age'];
      $height=$row['height'];
      $weight=$row['weight'];
      $phone=$row['phone'];
      $ref_code=$row['ref_code'];
      $image=$row['image'];
    }
  }
  $sql = "select count(*) from challenges where (status=0 or status=1) and user_id='{$_SESSION['userid']}'";
  $result = mysqli_query($conn,$sql);
  if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
           $count=$row['count(*)'];
            // echo "count".$count;
       }
  }
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Leader</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">


    <link rel="stylesheet" href="assets/css/style.css">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Cuprum" rel="stylesheet">    <style>
    .hidden { display: none; }
    .unhidden { display: inline; }
    </style>




</head>

<body class="bg-dark" style="font-family: 'Cuprum', sans-serif; ">


  <!-- Left Panel -->

  <aside id="left-panel" class="left-panel">
      <nav class="navbar navbar-expand-sm navbar-default">

        <div class="navbar-header">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="./"><img src="images/logo-white.png" alt="Logo" height="30px"></a>
            <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
        </div>

          <div id="main-menu" class="main-menu collapse navbar-collapse">
              <ul class="nav navbar-nav">
                  <li>
                      <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                  </li>
                  <li class="active">
                      <a href="leaderboard.php"> <i class="menu-icon fa fa-trophy"></i>Leaderboard </a>
                  </li>
                  <li>
                      <a href="goal.php"> <i class="menu-icon fa fa-list-alt"></i>Goal </a>
                  </li>
                  <h3 class="menu-title">Event</h3>
                  <li><a href="event.php"> <i class="menu-icon fa fa-calendar-plus-o"></i>Add Event </a></li>
                  <li><a href="eventdis.php"> <i class="menu-icon fa fa-calendar"></i>View Event </a></li>



              </ul>
          </div><!-- /.navbar-collapse -->
      </nav>
  </aside><!-- /#left-panel -->

  <!-- Right Panel -->

  <div id="right-panel" class="right-panel">

      <!-- Header-->
      <header id="header" class="header">

          <div class="header-menu">

              <div class="col-sm-7">
                  <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                  <div class="header-left">

                  </div>
              </div>

              <div class="col-sm-5">
                  <div class="user-area dropdown float-right">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <img class="user-avatar rounded-circle" src=<?php echo $image;?> alt="User Avatar">
                      </a>

                      <div class="user-menu dropdown-menu">
                          <a class="nav-link" href="profile.php"><i class="fa fa-user"></i> My Profile</a>

                          <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                      </div>
                  </div>
              </div>
          </div>

      </header><!-- /header -->
      <!-- Header-->


        <div class="content mt-3">
          <div class="col-lg-12">
              <div class="card">
                  <div class="card-header">
                      <strong class="card-title">Leader Board</strong>
                  </div>
                  <div class="card-body">
                      <table class="table table-dark">
                          <thead>
                              <tr>
                                  <th scope="col">#</th>
                                  <th scope="col">User name</th>
                                  <th scope="col">Score</th>
                                  <th scope="col">Level</th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php
                              $sql = "select userid,sum(score) from scorecard group by userid order by sum(score) desc";
                              $result = mysqli_query($conn,$sql);
                              if (mysqli_num_rows($result) > 0) {
                                $i=1;
                                while($row = mysqli_fetch_assoc($result)) {
                                  $sql1 = "select sum(score) from scorecard where userid=".$row['userid'];
                                  $result1 = mysqli_query($conn,$sql1);
                                  if ($row1 = mysqli_fetch_assoc($result1)) {
                                    $score=$row1['sum(score)'];
                                    $level=intval($score/20)+1;
                                  } ?>
                                  <tr>
                                     <th scope="row"><?php echo $i;?></th>
                                     <td><?php echo $row['userid'];?></td>
                                      <td><?php echo $row['sum(score)'];?></td>
                                      <td><?php echo $level;?></td>
                                 </tr>
                                  <?php
                                      $i=$i+1;}
                              }
                                ?>
                          </tbody>
                      </table>
                  </div>
              </div>
          </div




          </div>



        </div> <!-- .content -->
    </div><!-- /#right-panel -->
<?php
} else {
  echo "shit";
}
 ?>
    <!-- Right Panel -->

    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script>
        (function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });
        })(jQuery);
    </script>
    <script type="text/javascript">
    function unhide123(divID) {
    var item = document.getElementById(divID);
    if (item) {
    item.className=(item.className=='hidden')?'unhidden':'hidden';
    }
    }
    </script>

</body>

</html>
