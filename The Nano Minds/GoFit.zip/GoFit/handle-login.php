<?php include 'config_db.php';
session_start();
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

// define variables and set to empty values
  $user = $_POST["username"];
  $password = $_POST["password"];
	$password = hash('sha256',$password);

  $sql = " SELECT `username` FROM `users` WHERE `username` = '".$user."'";
  $result = mysqli_query($conn, $sql);
  if($user==""){
  }
	else{
  if (mysqli_num_rows($result) > 0) {
	  while ($row = mysqli_fetch_array($result)){
		  if( $row['username']==$user){
				$sql1 = " SELECT `id`,`password` FROM `users` WHERE `username` = '".$user."'";
        $result1 = mysqli_query($conn, $sql1);
        if (mysqli_num_rows($result1) > 0) {
          while ($row1 = mysqli_fetch_array($result1)){
					  if( $row1['password']==$password){
							$_SESSION['userid']=$row1['id'];
              echo "<script type=\"text/javascript\">";
       				echo "window.location.href='dashboard.php';";
        			echo "</script>";
            }
						else{
							echo "<script type=\"text/javascript\">";
  						echo "alert (\"Incorrect Password and Username Combination...\");";
 						  echo "window.location.href='login.php';";
  						echo "</script>";
						}
					}
				}
		  }
    }
	}
	else{
	  echo "<script type=\"text/javascript\">";
		echo "alert (\"Account Not Present...\");";
		echo "window.location.href='signup.php';";
		echo "</script>";
	}
}
?>
