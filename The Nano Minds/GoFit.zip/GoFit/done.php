<?php
include 'config_db.php';
include 'session.php';
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
// echo $_SESSION['userid'];
$chname=$_POST['chname'];
$des=$_POST['des'];
if(!empty($_POST['check_list'])){
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list'] as $selected){
  $sql = "insert into challenges (`friend_id`, `user_id`, `ch_name`, `description`, `status`) values  ('".$_SESSION['userid']."','".$selected."','".$chname."','".$des."','0')";
    $result = mysqli_query($conn,$sql);
    $sql = "insert into `scorecard` (`userid`,`score`,`timestamp`) values (".$_SESSION['userid'].",5, now())";
    $result = mysqli_query($conn,$sql);
echo $selected."</br>";
}
}
echo "<script> window.location.href='dashboard.php'</script>";

?>
