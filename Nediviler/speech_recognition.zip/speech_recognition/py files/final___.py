import speech_recognition as speech

record = speech.Recognizer()

with speech.Microphone() as source:
    print("MICROPHONE ON, RECORDING....");
    audio = record.listen(source)
    print("RECORDED!")

try:
    #print("TEXT: "+record.recognize_google(audio,language = 'hi-IN'));
    print("TEXT: "+record.recognize_google(audio));
except:
    pass;
